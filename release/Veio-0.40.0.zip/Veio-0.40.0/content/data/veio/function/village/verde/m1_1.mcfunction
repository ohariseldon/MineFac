# Gerado por tools/vila/build_village.py. Árvores e canteiros da vila, relativos ao centro.
execute positioned ~-18 ~ ~63 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ minecraft:grass_block run place feature minecraft:oak ~ ~ ~
execute positioned ~-23 ~ ~51 positioned over motion_blocking_no_leaves run place feature minecraft:patch_grass ~ ~ ~
execute positioned ~-19 ~ ~60 positioned over motion_blocking_no_leaves run place feature minecraft:patch_grass ~ ~ ~
