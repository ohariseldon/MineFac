# Gerado por tools/vila/build_village.py. Árvores e canteiros da vila, relativos ao centro.
execute positioned ~100 ~ ~83 positioned over motion_blocking_no_leaves if block ~ ~-1 ~ minecraft:grass_block run place feature minecraft:fancy_oak ~ ~ ~
